const bcrypt = require('bcryptjs'); // Import bcryptjs library
const jwt = require('jsonwebtoken');
const { createUser, loginUser, createPost, getEdukasiArticle, getHistoryByEmail } = require('../models/userModel');

const registerUser = async (req, res) => {
    const { body } = req;

    if (
        typeof body.email !== 'string' ||
        typeof body.password !== 'string' ||
        !body.email.trim() ||
        !body.password.trim()
    ) {
        return res.status(400).json({
            message: 'Invalid data provided',
            data: null,
        });
    }

    const hashedPassword = await bcrypt.hash(body.password, 10);

    const userData = {
        email: body.email.trim(),
        password: hashedPassword,
    };

    // Buat pengguna baru
    try {
        await createUser(userData);

        res.status(201).json({
            message: 'User created successfully',
            data: { email: userData.email },  // Jangan kirim password hash dalam respon
        });
    } catch (error) {
        res.status(500).json({
            message: 'Server error while creating user',
            serverMessage: error.message,
        });
    }
};

const authenticateUser = async (req, res) => {
    try {
        // Asumsikan loginUser adalah fungsi yang menangani proses login
        // dan mengembalikan objek yang berisi token jika login berhasil
        const result = await loginUser(req.body);
        
        // Jika login berhasil, kembalikan respon dengan status 200 dan pesan sukses
        res.status(200).json({ message: 'Login successful', token: result.token });
    } catch (error) {
        // Jika ada kesalahan (misalnya, kredensial yang salah), kembalikan respon dengan status 400 dan pesan kesalahan
        res.status(400).json({ error: error.message });
    }
}


// post

const savePost = async (req, res) => {
    const { judul, penulis, rating, halaman, stok } = req.body;

    // Validate and parse data
    let parsedRating = parseFloat(rating);
    let parsedHalaman = parseInt(halaman);
    let parsedStok = parseInt(stok);

    // Data validation
    if (
        typeof judul !== 'string' || !judul.trim() ||
        typeof penulis !== 'string' || !penulis.trim() ||
        typeof parsedRating !== 'number' || isNaN(parsedRating) || parsedRating < 0 || parsedRating > 5 ||
        typeof parsedHalaman !== 'number' || isNaN(parsedHalaman) || parsedHalaman <= 0 ||
        typeof parsedStok !== 'number' || isNaN(parsedStok) || parsedStok < 0
    ) {
        console.log('Invalid data provided:', req.body); // Debugging print statement
        return res.status(400).json({
            message: 'Invalid data provided',
            data: null,
        });
    }

    const postData = {
        judul: judul.trim(),
        penulis: penulis.trim(),
        rating,
        halaman,
        stok,
    };

    try {
        console.log('Data to be saved:', postData); // Debugging print statement
        await createPost(postData); // Assume createPost is a function that handles inserting data into the database

        res.status(201).json({
            message: 'Post created successfully',
            data: postData,
        });
    } catch (error) {
        console.log('Error saving data:', error); // Debugging print statement
        res.status(500).json({
            message: 'Server Error',
            serverMessage: error.message,
        });
    }
};

// post

const getEdukasi = async (req, res) => {
    try {
      const articles = await getEdukasiArticle();
      res.json({ books: articles });
    } catch (err) {
      console.error('Error fetching articles:', err);
      res.status(500).json({ error: 'Internal Server Error' });
    }
  };
//   router.get('/edukasi', authenticateJWT, getEdukasi);
// // const getJadwal => () {

// };

const getByJudul = async (req, res) => {
    const judul = req.body.judul || req.query.judul || req.params.judul;

    if (!judul) {
        return res.status(400).json({ error: 'Judul is required' });
    }

    try {
        const history = await getHistoryByEmail(judul);
        res.json(history);
    } catch (error) {
        console.error('Error fetching history by judul:', error);
        res.status(500).json({ error: 'Internal Server Error' });
    }
};

module.exports = { registerUser, authenticateUser, savePost, getEdukasi, getByJudul};