const dbPool = require('../config/database');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const createUser = async (userData) => {
    const { email, password } = userData;
    // Hash password using bcrypt
    const hashedPassword = await bcrypt.hash(password, 10); // 10 adalah cost factor untuk bcrypt
    const SQLQuery = `INSERT INTO users (email, password) VALUES (?, ?)`;
    await dbPool.execute(SQLQuery, [email, hashedPassword]);
}


const loginUser = async (body) => {
    const { email, password } = body;
    const SQLQuery = `SELECT * FROM users WHERE email = ?`;

    try {
        const [rows] = await dbPool.execute(SQLQuery, [email]);
        if (rows.length === 0) {
            throw new Error('User not found');
        }

        const user = rows[0];

        // Perhatikan bahwa di sini kita membandingkan password plaintext
        if (password !== user.password) {
            throw new Error('Invalid password');
        }

        const token = jwt.sign({ email: user.email }, process.env.JWT_SECRET, { expiresIn: '1h' });
        return { token };
    } catch (error) {
        throw new Error(error.message);
    }
}


const createPost = async (postData) => {
    const { judul, penulis, rating, halaman, stok } = postData;
    const SQLQuery = `INSERT INTO pengembalian (judul, penulis, rating, halaman, stok) VALUES (?, ?, ?, ?, ?)`;
    await dbPool.execute(SQLQuery, [judul, penulis, rating, halaman, stok]);
};

const getEduhkasi = async () => {

};

const getEdukasiArticle = async () => {
    const SQLQuery = 'SELECT * FROM buku';
    const [rows] = await dbPool.execute(SQLQuery);
    return rows;
  };

  const getHistoryByEmail = async (judul) => {
    const SQLQuery = 'SELECT * FROM pengembalian WHERE judul = ?';
    try {
        const [rows, fields] = await dbPool.execute(SQLQuery, [judul]);
        return rows;
    } catch (error) {
        console.error('Error fetching history by judul:', error); // Log the error for debugging
        throw error; // Rethrow the error to be handled by the caller
    }
};
module.exports = { createUser, loginUser, createPost, getEdukasiArticle
    , getHistoryByEmail };