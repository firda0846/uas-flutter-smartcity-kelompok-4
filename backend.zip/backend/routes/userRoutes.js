const express = require('express');
const router = express.Router();
const { registerUser, authenticateUser, savePost, getEdukasi, getByJudul } = require('../controller/userControl');
const authenticateJWT = require('../middleware/authMiddleware');
const upload = require('../middleware/multer');

router.post('/register', registerUser);
router.post('/login', authenticateUser);
router.get('/edukasi', authenticateJWT, getEdukasi);
router.get('/history', authenticateJWT, getByJudul)

router.post('/posting', authenticateJWT, savePost);
router.post('/upload', authenticateJWT, upload.single('photo'), (req, res) => {
    res.json({
        message: 'Upload Berhasil'
    });
});

// Example of a protected route
// router.get('/protected', authenticateJWT, (req, res) => {
//     res.status(200).json({ message: 'This is a protected route', user: req.user });
// });

module.exports = router;
